# Menu_IA
# Menu para mostrar tema de IA
        cout << "                                                                             " << endl;
        cout << "                                                                             " << endl;
        cout << "                33333   IIIIII  M       M    1111    000000                  " << endl;
        cout << "                     3    II    M M   M M      11    0    0                  " << endl;
        cout << "                  3333    II    M   M   M      11    0    0                  " << endl;
        cout << "                     3    II    M       M      11    0    0                  " << endl;
        cout << "                33333   IIIIII  M       M    111111  000000                  " << endl;
        cout << "                                                                             " << endl;
        cout << "                                                                             " << endl;
        cout << "              EEEEEE  QQQQQQ   U    U   IIIIII  PPPPP   OOOOOO               " << endl;
        cout << "              E       Q    Q   U    U     II    P    P  O    O               " << endl;
        cout << "              EEEE    Q  Q Q   U    U     II    PPPPPP  O    O               " << endl;
        cout << "              E       Q   QQ   U    U     II    P       O    O               " << endl;
        cout << "              EEEEEE  QQQQQQ   UUUUUU   IIIIII  P       OOOOOO               " << endl;
        cout << "                            Q                                                " << endl;
        cout << "                                                                             " << endl;
        cout << "                                                                             " << endl;
        cout << "           EEEEEE  N    N   TTTTTT  OOOOOO  RRRRR   N    N  OOOOOO           " << endl;
        cout << "           E       NN   N     TT    O    O  R    R  NN   N  O    O           " << endl;
        cout << "           EEEE    N N  N     TT    O    O  R RRR   N N  N  O    O           " << endl;
        cout << "           E       N  N N     TT    O    O  R    R  N  N N  O    O           " << endl;
        cout << "           EEEEEE  N    N     TT    OOOOOO  R    R  N    N  OOOOOO           " << endl;
        cout << "                                                                             " << endl;
        cout << "                                                                             " << endl;
        cout << "                                                                             " << endl;
        cout << "                              Integrantes:                                   " << endl;
        cout << "                                                                             " << endl;
        cout << "                    Barragan Hernandez Rodrigo Iñaki.                        " << endl;
        cout << "                    Flores Reyes Hanny Michelle.                             " << endl;
        cout << "                    Gaona Cruz Hector Yael.                                  " << endl;
        cout << "                    Martin del Campo Gomez María Fernanda.                   " << endl;
        cout << "                    Peña Larraga Dulce Montserrath.                          " << endl;
        cout << "                                                                             " << endl;
        cout << "                                                                             " << endl;
        cout << "                                 Tema:                                       " << endl;
        cout << "                                                                             " << endl;
        cout << "                       La Inteligencia Artificial                            " << endl;
        cout << "                                                                             " << endl;
        cout << "                                                                             " << endl;
        cout << "                                                                             " << endl;
        
        pon cualquier usuario y la clave es 123
